# SVG Quality Predictor - Training Data Package

Generated on: 2025-09-29 23:40:03.800542

## Dataset Overview

- **Total Examples**: 422
- **Total Images**: 422
- **Average SSIM**: 0.801
- **SSIM Range**: 0.000 - 0.997

## Logo Type Distribution

- **simple**: 57 examples
- **text**: 155 examples
- **gradient**: 55 examples
- **complex**: 155 examples

## Quality Distribution

- **High Quality (>0.9)**: 56 examples
- **Medium Quality (0.7-0.9)**: 346 examples
- **Low Quality (<0.7)**: 20 examples

## Data Sources

- **existing_benchmark**: 20 examples
- **existing_parameter_cache**: 2 examples
- **parameter_variation**: 200 examples
- **systematic_sweep**: 200 examples

## Usage in Colab

1. Upload this ZIP file to your Colab environment
2. Extract the contents
3. Load the training metadata: `json.load(open('training_metadata.json'))`
4. Begin GPU-accelerated training with the provided examples

## Parameter Ranges

All VTracer parameters are within the following ranges:
- **color_precision**: 1-16
- **layer_difference**: 1-16
- **corner_threshold**: 10-100
- **length_threshold**: 1.0-20.0
- **max_iterations**: 1-30
- **splice_threshold**: 10-100
- **path_precision**: 1-20

## Next Steps

This dataset is ready for GPU training in Google Colab. Use the provided training notebook to:
1. Load and preprocess the data
2. Extract ResNet-50 features using GPU acceleration
3. Train the quality prediction model
4. Export the trained model for local deployment
